<?php
/**
 * Created by PhpStorm.
 * User: Muhammad Abubakar
 * Date: 4/13/2018
 * Time: 1:19 PM
 */

return [
    'IMAGE_URL' => 'uploads/files/Image/',
];
