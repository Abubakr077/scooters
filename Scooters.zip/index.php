<?php
/**
 * Created by PhpStorm.
 * User: InfoCaliper
 * Date: 12/19/2017
 * Time: 11:58 AM
 */
phpinfo();
