<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\FavAds;
use Faker\Generator as Faker;

$factory->define(FavAds::class, function (Faker $faker) {
    return [
        //
    ];
});
