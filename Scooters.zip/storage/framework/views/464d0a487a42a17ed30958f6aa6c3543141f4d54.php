<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
                <div class="col-lg-12">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Orders</li>
        </ol>
    </nav>
                </div>

    <div class="row">
        <div id="content" class="col-sm-12">
            <h2 class="title">Order History</h2>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                    <tr>
                        <td class="text-center">Image</td>
                        <td class="text-left">Product Name</td>
                        <td class="text-center">Order ID</td>
                        <td class="text-center">Quantity</td>
                        <td class="text-center">Status</td>
                        <td class="text-center">Address</td>
                        <td class="text-center">Date Added</td>
                        <td class="text-right">Total</td>
                        <td></td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center">
                            <a href="#"><img width="85" class="img-thumbnail" title="kheri" alt="" src="<?php echo e(asset($order->picture)); ?>">
                            </a>
                        </td>
                        <td class="text-left"><a href="#"><?php echo e($order->name); ?></a>
                        </td>
                        <td class="text-center"><?php echo e($order->id); ?></td>
                        <td class="text-center"><?php echo e($order->quantity); ?></td>
                        <td class="text-center">Shipped</td>
                        <td class="text-center"><?php echo e($order->house. ' '. $order->address. ' '.$order->city.' Pakistan'); ?></td>
                        <td class="text-center"><?php echo e($order->created_at); ?></td>
                        <td class="text-right">RS <?php echo e($order->price); ?></td>
                        <td class="text-center"><a class="btn btn-info" title="" data-toggle="tooltip" href="#" data-original-title="View"><i class="fa fa-eye"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Muhammad Abubakar\PhpstormProjects\Scooters\resources\views/user/order-history.blade.php ENDPATH**/ ?>