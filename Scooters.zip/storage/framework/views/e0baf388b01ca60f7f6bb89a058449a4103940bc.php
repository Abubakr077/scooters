<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body>
<a href="javascript:" id="return-to-top"><i class="fa fa-angle-up"></i></a>
<div class="wrapper">
    <div class="banner">
        <?php echo $__env->make('layouts.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('search'); ?>
    </div>
    <?php echo $__env->yieldContent('content'); ?>
</div>
</body>
</html>
<?php /**PATH C:\Users\Muhammad Abubakar\PhpstormProjects\Scooters\resources\views/layouts/mainlayout.blade.php ENDPATH**/ ?>