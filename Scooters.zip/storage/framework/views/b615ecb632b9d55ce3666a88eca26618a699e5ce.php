<?php $__env->startSection('content'); ?>
    <section class="page-section text-left">
        <div class="container sec-1">
            <div class="row">
                <h2>Available Bikes</h2>
                <p>See which frenchise is selling in your area. Find a bike close to home.</p>
            </div>
        </div>
        <div class="container bikes-sec">
            <div class="row">
                <div class="col-md-3 col-sm-4 col-xs-12 result">
                    <h4 class="show">Show Results by:</h4>
                    <form role="form" method="get" action="/bikes/search" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                    <ul>
                            <input type="text" name="keyword" id="keyword" value="<?php echo e($filters['keyword']); ?>" class="form-control" placeholder="Search">
                        <li>
                            <h4>Brand</h4>
                            <select class="form-control" name="brand">
                                <option value=""> --- Please Select --- </option>
                                <option value="Honda" <?php echo e($filters['brand'] == 'Honda' ? 'selected' : ''); ?>>Honda</option>
                                <option value="Yamaha" <?php echo e($filters['brand'] == 'Yamaha' ? 'selected' : ''); ?>>Yamaha</option>
                                <option value="Suzuki" <?php echo e($filters['brand'] == 'Suzuki' ? 'selected' : ''); ?>>Suzuki</option>
                                <option value="Super Power" <?php echo e($filters['brand'] == 'Super Power' ? 'selected' : ''); ?>>Super Power</option>
                                <option value="United" <?php echo e($filters['brand'] == 'United' ? 'selected' : ''); ?>>United</option>
                                <option value="Unique" <?php echo e($filters['brand'] == 'Unique' ? 'selected' : ''); ?>>Unique</option>
                                <option value="Kawasaki" <?php echo e($filters['brand'] == 'Kawasaki' ? 'selected' : ''); ?>>Kawasaki</option>
                            </select>
                        </li>
                        <li>
                            <h4>Year Range</h4>
                            <section class="range-slider">
                                <span class="rangeValues"></span>
                                <input value="<?php echo e($filters['minYear'] != '' ? $filters['minYear'] : '1980'); ?>" min="1980" max="2021" step="1" type="range" name="minYear">
                                <input value="<?php echo e($filters['maxYear'] != '' ? $filters['maxYear'] : '2021'); ?>" min="1980" max="2021" step="1" type="range" name="maxYear">
                            </section>
                        </li>
                        <li>
                            <h4>Price Range</h4>
                            <section class="range-slider">
                                <span class="rangeValues"></span>
                                <input value="<?php echo e($filters['minPrice'] != '' ? $filters['minPrice'] : '8000'); ?>" min="8000" max="250000" step="8000" type="range" name="minPrice">
                                <input value="<?php echo e($filters['maxPrice'] != '' ? $filters['maxPrice'] : '250000'); ?>" min="8000" max="250000" step="500" type="range" name="maxPrice">
                            </section>
                        </li>
                        <li>
                            <h4>Registration City</h4>
                            <select class="form-control" name="regCity">
                                <option value=""> --- Please Select --- </option>
                                <option value="Lahore" <?php echo e($filters['regCity'] == 'Lahore' ? 'selected' : ''); ?>>Lahore</option>
                                <option value="Karachi" <?php echo e($filters['regCity'] == 'Karachi' ? 'selected' : ''); ?>>Karachi</option>
                                <option value="Islamabad" <?php echo e($filters['regCity'] == 'Islamabad' ? 'selected' : ''); ?>>Islamabad</option>
                                <option value="Multan" <?php echo e($filters['regCity'] == 'Multan' ? 'selected' : ''); ?>>Multan</option>
                                <option value="Bwp" <?php echo e($filters['regCity'] == 'Bwp' ? 'selected' : ''); ?>>Bwp</option>
                                <option value="Rawalpindi" <?php echo e($filters['regCity'] == 'Rawalpindi' ? 'selected' : ''); ?>>Rawalpindi</option>
                                <option value="Peshawar" <?php echo e($filters['regCity'] == 'Peshawar' ? 'selected' : ''); ?>>Peshawar</option>
                                <option value="Quetta" <?php echo e($filters['regCity']=='Quetta' ? 'selected' : ''); ?>>Quetta</option>
                            </select>
                        </li>
                        <li>
                            <h4>City</h4>
                            <select class="form-control" name="city">
                                <option value=""> --- Please Select --- </option>
                                <option value="Lahore" <?php echo e($filters['city'] == 'Lahore' ? 'selected' : ''); ?>>Lahore</option>
                                <option value="Karachi" <?php echo e($filters['city'] == 'Karachi' ? 'selected' : ''); ?>>Karachi</option>
                                <option value="Islamabad" <?php echo e($filters['city'] == 'Islamabad' ? 'selected' : ''); ?>>Islamabad</option>
                                <option value="Multan" <?php echo e($filters['city'] == 'Multan' ? 'selected' : ''); ?>>Multan</option>
                                <option value="Bwp" <?php echo e($filters['city'] == 'Bwp' ? 'selected' : ''); ?>>Bwp</option>
                                <option value="Rawalpindi" <?php echo e($filters['city'] == 'Rawalpindi' ? 'selected' : ''); ?>>Rawalpindi</option>
                                <option value="Peshawar" <?php echo e($filters['city'] == 'Peshawar' ? 'selected' : ''); ?>>Peshawar</option>
                                <option value="Quetta" <?php echo e($filters['city']=='Quetta' ? 'selected' : ''); ?>>Quetta</option>
                            </select>
                        </li>
                        <li>
                            <h4>Province</h4>
                            <select class="form-control" name="province">
                                <option value=""> --- Please Select --- </option>
                                <option value="Punjab" <?php echo e($filters['province']=='Punjab' ? 'selected' : ''); ?>>Punjab</option>
                                <option value="Sindh" <?php echo e($filters['province']=='Sindh' ? 'selected' : ''); ?>>Sindh</option>
                                <option value="KPK" <?php echo e($filters['province']=='KPK' ? 'selected' : ''); ?>>KPK</option>
                                <option value="Balochistan" <?php echo e($filters['province']=='Balochistan' ? 'selected' : ''); ?>>Balochistan</option>
                                <option value="Azad Kashmir" <?php echo e($filters['province']=='Azad Kashmir' ? 'selected' : ''); ?>>Azad Kashmir</option>
                                <option value="Federally Administered Tribal Areas" <?php echo e($filters['province']=='Federally Administered Tribal Areas' ? 'selected' : ''); ?>>Federally Administered Tribal Areas</option>
                            </select>
                        </li>
                        <li>
                            <h4>Color</h4>
                            <select class="form-control" name="color">
                                <option value=""> --- Please Select --- </option>
                                <option value="Red" <?php echo e($filters['color']=='Red' ? 'selected' : ''); ?>>Red</option>
                                <option value="Black" <?php echo e($filters['color']=='Black' ? 'selected' : ''); ?>>Black</option>
                                <option value="White" <?php echo e($filters['color']=='White' ? 'selected' : ''); ?>>White</option>
                                <option value="Green" <?php echo e($filters['color']=='Green' ? 'selected' : ''); ?>>Green</option>
                                <option value="Blue" <?php echo e($filters['color']=='Blue' ? 'selected' : ''); ?>>Blue</option>
                                <option value="Orange" <?php echo e($filters['color']=='Orange' ? 'selected' : ''); ?>>Orange</option>
                                <option value="Yellow" <?php echo e($filters['color']=='Yellow' ? 'selected' : ''); ?>>Yellow</option>
                                <option value="Multi" <?php echo e($filters['color']=='Multi' ? 'selected' : ''); ?>>Multi</option>
                            </select>
                        </li>
                        <li>
                            <h4>Mileage Range</h4>
                            <section class="range-slider">
                                <span class="rangeValues"></span>
                                <input value="<?php echo e($filters['minMileage'] != '' ? $filters['minMileage'] : '15'); ?>" min="15" max="200" step="5" type="range" name="minMileage">
                                <input value="<?php echo e($filters['maxMileage'] != '' ? $filters['maxMileage'] : '200'); ?>" min="15" max="200" step="5" type="range" name="maxMileage">
                            </section>
                        </li>
                        <li>
                            <h4>Engine Type</h4>
                            <select class="form-control" name="type">
                                <option value=""> --- Please Select --- </option>
                                <option value="4 Stroke" <?php echo e($filters['type']=='4 Stroke' ? 'selected' : ''); ?>>4 Stroke</option>
                                <option value="2 Stroke" <?php echo e($filters['type']=='2 Stroke' ? 'selected' : ''); ?>>2 Stroke</option>
                                <option value="Electric" <?php echo e($filters['type']=='Electric' ? 'selected' : ''); ?>>Electric</option>
                            </select>
                        </li>
                        <li>
                            <h4>Engine Capacity</h4>
                            <section class="range-slider">
                                <span class="rangeValues"></span>
                                <input value="<?php echo e($filters['minCapacity'] != '' ? $filters['minCapacity'] : '70'); ?>" min="70" max="700" step="10" type="range" name="minCapacity">
                                <input value="<?php echo e($filters['maxCapacity'] != '' ? $filters['maxCapacity'] : '700'); ?>" min="70" max="700" step="10" type="range" name="maxCapacity">
                            </section>
                        </li>
                        <li>
                            <h4>Body Type</h4>
                            <select class="form-control" name="bodyType">
                                <option value=""> --- Please Select --- </option>
                                <option value="ATV" <?php echo e($filters['bodyType']=='ATV' ? 'selected' : ''); ?>>ATV</option>
                                <option value="Cruiser" <?php echo e($filters['bodyType']=='Cruiser' ? 'selected' : ''); ?>>Cruiser</option>
                                <option value="Scooter" <?php echo e($filters['bodyType']=='Scooter' ? 'selected' : ''); ?>>Scooter</option>
                                <option value="Sports" <?php echo e($filters['bodyType']=='Sports' ? 'selected' : ''); ?>>Sports</option>
                                <option value="Standard" <?php echo e($filters['bodyType']=='Standard' ? 'selected' : ''); ?>>Standard</option>
                                <option value="Tourer" <?php echo e($filters['bodyType']=='Tourer' ? 'selected' : ''); ?>>Tourer</option>
                                <option value="Trail" <?php echo e($filters['bodyType']=='Trail' ? 'selected' : ''); ?>>Trail</option>
                                <option value="Others" <?php echo e($filters['bodyType']=='Others' ? 'selected' : ''); ?>>Others</option>
                            </select>
                        </li>

                        <button class="btn btn-default" type="submit">Submit</button>
                    </ul>
                    </form>
                </div>
                <div class="col-md-9 col-sm-8 col-xs-12">
                    <?php $__currentLoopData = $bikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12">
                        <div class="cs-services box right">
                            <figure> <img class="img-responsive" src="<?php echo e(url($item->photos()->first()->getPicture())); ?>"></figure>
                            <div class="heading"><h5>
                                    <a href="<?php echo e('/0/bikes/'.$item->id); ?>"><?php echo e($item->name); ?></a>
                                </h5>
                                <p><?php echo e($item->price); ?></p>
                                <p><?php echo e($item->description); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $bikes->links(); ?>

                </div>
            </div>
        </div>
    </section>

    <section class="page-section">
        <div class="container sec-1 happy-customers">
            <div class="row">
                <h2>Happy Customers</h2>
                <p>See which frenchise is selling in your area. Find a bike close to home.</p>

                <div class="col-md-6 col-sm-6 col-xs-12">
                    <h3><strong>Testimonial</strong></h3>
                    <div class="seprator"></div>
                    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                        <!-- Wrapper for slides -->
                        <div class="carousel-inner">
                            <div class="item active">
                                <div class="row" style="padding: 20px">
                                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                                    <p class="testimonial_para">Lorem Ipsum ist ein einfacher Demo-Text für die Print- und Schriftindustrie. Lorem Ipsum ist in der Industrie bereits der Standard Demo-Text "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo en.</p><br>
                                    <div class="row">
                                        <div class="col-sm-2">
                                            <img src="http://demos1.showcasedemos.in/jntuicem2017/html/v1/assets/images/jack.jpg" class="img-responsive" style="width: 80px">
                                        </div>
                                        <div class="col-sm-10">
                                            <h4><strong>Jack Andreson</strong></h4>
                                            <p class="testimonial_subtitle"><span>Chlinical Chemistry Technologist</span><br>
                                                <span>Officeal All Star Cafe</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="row" style="padding: 20px">
                                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                                    <p class="testimonial_para">Lorem Ipsum ist ein einfacher Demo-Text für die Print- und Schriftindustrie. Lorem Ipsum ist in der Industrie bereits der Standard Demo-Text "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo en.</p><br>
                                    <div class="row">
                                        <div class="col-sm-2">
                                            <img src="http://demos1.showcasedemos.in/jntuicem2017/html/v1/assets/images/kiara.jpg" class="img-responsive" style="width: 80px">
                                        </div>
                                        <div class="col-sm-10">
                                            <h4><strong>Kiara Andreson</strong></h4>
                                            <p class="testimonial_subtitle"><span>Chlinical Chemistry Technologist</span><br>
                                                <span>Officeal All Star Cafe</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="controls testimonial_control pull-right">
                        <a class="left fa fa-chevron-left btn btn-default testimonial_btn" href="#carousel-example-generic"
                           data-slide="prev"></a>

                        <a class="right fa fa-chevron-right btn btn-default testimonial_btn" href="#carousel-example-generic"
                           data-slide="next"></a>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <h3><strong>Testimonial</strong></h3>
                    <div class="seprator"></div>
                    <div id="carousel-example-generic2" class="carousel slide" data-ride="carousel">
                        <!-- Wrapper for slides -->
                        <div class="carousel-inner">
                            <div class="item active">
                                <div class="row" style="padding: 20px">
                                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                                    <p class="testimonial_para">Lorem Ipsum ist ein einfacher Demo-Text für die Print- und Schriftindustrie. Lorem Ipsum ist in der Industrie bereits der Standard Demo-Text "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo en.</p><br>
                                    <div class="row">
                                        <div class="col-sm-2">
                                            <img src="http://demos1.showcasedemos.in/jntuicem2017/html/v1/assets/images/jack.jpg" class="img-responsive" style="width: 80px">
                                        </div>
                                        <div class="col-sm-10">
                                            <h4><strong>Jack Andreson</strong></h4>
                                            <p class="testimonial_subtitle"><span>Chlinical Chemistry Technologist</span><br>
                                                <span>Officeal All Star Cafe</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="row" style="padding: 20px">
                                    <button style="border: none;"><i class="fa fa-quote-left testimonial_fa" aria-hidden="true"></i></button>
                                    <p class="testimonial_para">Lorem Ipsum ist ein einfacher Demo-Text für die Print- und Schriftindustrie. Lorem Ipsum ist in der Industrie bereits der Standard Demo-Text "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo en.</p><br>
                                    <div class="row">
                                        <div class="col-sm-2">
                                            <img src="http://demos1.showcasedemos.in/jntuicem2017/html/v1/assets/images/kiara.jpg" class="img-responsive" style="width: 80px">
                                        </div>
                                        <div class="col-sm-10">
                                            <h4><strong>Kiara Andreson</strong></h4>
                                            <p class="testimonial_subtitle"><span>Chlinical Chemistry Technologist</span><br>
                                                <span>Officeal All Star Cafe</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="controls testimonial_control pull-right">
                        <a class="left fa fa-chevron-left btn btn-default testimonial_btn" href="#carousel-example-generic2"
                           data-slide="prev"></a>

                        <a class="right fa fa-chevron-right btn btn-default testimonial_btn" href="#carousel-example-generic2"
                           data-slide="next"></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <main class="wow fadeInDown page-section" style="visibility: visible; animation-name: fadeInDown;">
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>

    <script type="text/javascript" src="js/script.js"></script>
    <script type="text/javascript" src="js/wow.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script>
        function getVals(){
            // Get slider values
            var parent = this.parentNode;
            var slides = parent.getElementsByTagName("input");
            var slide1 = parseFloat( slides[0].value );
            var slide2 = parseFloat( slides[1].value );
            // Neither slider will clip the other, so make sure we determine which is larger
            if( slide1 > slide2 ){ var tmp = slide2; slide2 = slide1; slide1 = tmp; }

            var displayElement = parent.getElementsByClassName("rangeValues")[0];
            displayElement.innerHTML = "" + slide1 + " - " + slide2 + "";

        }

        window.onload = function(){
            // Initialize Sliders
            var sliderSections = document.getElementsByClassName("range-slider");
            for( var x = 0; x < sliderSections.length; x++ ){
                var sliders = sliderSections[x].getElementsByTagName("input");
                for( var y = 0; y < sliders.length; y++ ){
                    if( sliders[y].type ==="range" ){
                        sliders[y].oninput = getVals;
                        // Manually trigger event first time to display values
                        sliders[y].oninput();
                    }
                }
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Muhammad Abubakar\PhpstormProjects\Scooters\resources\views/user/newbikes.blade.php ENDPATH**/ ?>