<div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
                <ul class="nomargin footer-links list-unstyled" id="footer-Make">
                    <li><h5>About us </h5></li>
                    <li><a href="#" id="footer_Toyota"
                           title="Toyota Bikes for Sale">Toyota Bikes for Sale</a></li>
                    <li><a href="#" id="footer_Suzuki"
                           title="Suzuki Bikes for Sale">Suzuki Bikes for Sale</a></li>
                    <li><a href="#" id="footer_Honda"
                           title="Honda Bikes for Sale">Honda Bikes for Sale</a></li>

                    <li><a href="#" id="footer_Daihatsu"
                           title="Daihatsu Bikes for Sale">Daihatsu Bikes for Sale</a></li>
                    <li><a href="#" id="footer_Mitsubishi"
                           title="Mitsubishi Bikes for Sale">Mitsubishi Bikes for Sale</a></li>

                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <ul class="nomargin footer-links list-unstyled" id="footer-City">
                    <li><h5>About scooter.pk</h5></li>
                    <li><a href="#" id="footer_Lahore"
                           title="Bikes for Sale in Lahore">Bikes in Lahore</a></li>
                    <li><a href="#" id="footer_Karachi"
                           title="Bikes for Sale in Karachi">Bikes in Karachi</a></li>
                    <li><a href="#" id="footer_Islamabad"
                           title="Bikes for Sale in Islamabad">Bikes in Islamabad</a></li>

                    <li><a href="#" id="footer_Gujranwala"
                           title="Bikes for Sale in Gujranwala">Bikes in Gujranwala</a></li>
                    <li><a href="#" id="footer_Faisalabad"
                           title="Bikes for Sale in Faisalabad">Bikes in Faisalabad</a></li>

                </ul>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <ul class="nomargin footer-links list-unstyled">
                    <li><h5>Our Products</h5></li>

                    <li><a href="#" title="Used Bikes">Used Bikes</a></li>

                    <li><a href="#" title="Used Bikes">Used Bikes</a></li>

                    <li><a href="#" title="New Bikes">New Bikes</a></li>

                    <li><a href="#" rel="nofollow" title="Scooters Autoshow">Autoshow</a></li>

                    <li><a href="#" title="Sitemap">Sitemap</a></li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <ul class="nomargin footer-links list-unstyled">

                    <li><h5>Advertise with us</h5></li>

                    <li><a href="#" rel="nofollow" title="About Scooters.com">About
                            Scooters.com</a></li>

                    <li><a href="#" rel="nofollow" title="Our Products">Our Products</a>
                    </li>

                    <li><a href="#" rel="nofollow" title="Advertise With Us">Advertise
                            With Us</a></li>

                    <li><a href="#" rel="nofollow"
                           title="How To Pay">How To Pay</a></li>

                    <li><a href="#" rel="nofollow" title="Contact Us">Contact Us</a>
                    </li>

                </ul>
            </div>
            <div class="col-md-6 col-sm-12 col-xs-12 footer-social">
                <h5>Follow Us</h5>
                <ul class="list-unstyled list-inline networks">
                    <li>
                        <a href="#" class="twitter" rel="nofollow"
                           target="_blank" title="Follow Us On Twitter"><i
                                class="fa fa-twitter"></i></a>
                    </li>
                    <li>
                        <a href="#" class="facebook" rel="nofollow"
                           target="_blank" title="Follow Us On Facebook"><i class="fa fa-facebook"></i></a>
                    </li>
                    <li>
                        <a href="#" class="googleplus"
                           rel="me" target="_blank" title="Follow Us On Google Plus"><i
                                class="fa fa-google-plus"></i></a>
                    </li>
                    <li>
                        <a href="#" class="pinterest" rel="nofollow"
                           target="_blank" title="Follow Us On Pinterest"><i
                                class="fa fa-pinterest"></i></a>
                    </li>

                </ul>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Muhammad Abubakar\PhpstormProjects\Scooters\resources\views/layouts/footer.blade.php ENDPATH**/ ?>