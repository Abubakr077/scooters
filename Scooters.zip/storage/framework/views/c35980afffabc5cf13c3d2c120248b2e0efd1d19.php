<?php $__env->startSection('content'); ?>

    <section class="page-section" style="margin-bottom: 60px;">
        <div class="container sec-1">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-left">Accessories</h2>
                    <p class="text-left">It's the fastest and simplest way to sell your automobile Accessory! <a class="btn btn-default pull-right" href="/0/accessories/create"> Sell Accessory</a></p>
                </div>
            </div>
        </div>
        <div class="container bikes-sec">
            <div class="row">
                <div class="col-md-3 col-sm-4 col-xs-12 result">
                    <h4 class="show">Show Results by:</h4>
                    <form role="form" method="get" action="/accessories/search" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <ul>
                            <input type="text" name="keyword" id="keyword" value="<?php echo e($filters['keyword']); ?>" class="form-control" placeholder="Search">
                            <li>
                                <h4>Brand</h4>
                                <select class="form-control" name="brand">
                                    <option value=""> --- Please Select --- </option>
                                    <option value="Honda" <?php echo e($filters['brand'] == 'Honda' ? 'selected' : ''); ?>>Honda</option>
                                    <option value="Yamaha" <?php echo e($filters['brand'] == 'Yamaha' ? 'selected' : ''); ?>>Yamaha</option>
                                    <option value="Suzuki" <?php echo e($filters['brand'] == 'Suzuki' ? 'selected' : ''); ?>>Suzuki</option>
                                    <option value="Super Power" <?php echo e($filters['brand'] == 'Super Power' ? 'selected' : ''); ?>>Super Power</option>
                                    <option value="United" <?php echo e($filters['brand'] == 'United' ? 'selected' : ''); ?>>United</option>
                                    <option value="Unique" <?php echo e($filters['brand'] == 'Unique' ? 'selected' : ''); ?>>Unique</option>
                                    <option value="Kawasaki" <?php echo e($filters['brand'] == 'Kawasaki' ? 'selected' : ''); ?>>Kawasaki</option>
                                </select>
                            </li>
                            <li>
                                <h4>Price Range</h4>
                                <section class="range-slider">
                                    <span class="rangeValues"></span>
                                    <input value="<?php echo e($filters['minPrice'] != '' ? $filters['minPrice'] : '1000'); ?>" min="1000" max="250000" step="1000" type="range" name="minPrice">
                                    <input value="<?php echo e($filters['maxPrice'] != '' ? $filters['maxPrice'] : '250000'); ?>" min="1000" max="250000" step="5000" type="range" name="maxPrice">
                                </section>
                            </li>
                            <li>
                                <h4>City</h4>
                                <select class="form-control" name="city">
                                    <option value=""> --- Please Select --- </option>
                                    <option value="Lahore" <?php echo e($filters['city'] == 'Lahore' ? 'selected' : ''); ?>>Lahore</option>
                                    <option value="Karachi" <?php echo e($filters['city'] == 'Karachi' ? 'selected' : ''); ?>>Karachi</option>
                                    <option value="Islamabad" <?php echo e($filters['city'] == 'Islamabad' ? 'selected' : ''); ?>>Islamabad</option>
                                    <option value="Multan" <?php echo e($filters['city'] == 'Multan' ? 'selected' : ''); ?>>Multan</option>
                                    <option value="Bwp" <?php echo e($filters['city'] == 'Bwp' ? 'selected' : ''); ?>>Bwp</option>
                                    <option value="Rawalpindi" <?php echo e($filters['city'] == 'Rawalpindi' ? 'selected' : ''); ?>>Rawalpindi</option>
                                    <option value="Peshawar" <?php echo e($filters['city'] == 'Peshawar' ? 'selected' : ''); ?>>Peshawar</option>
                                    <option value="Quetta" <?php echo e($filters['city']=='Quetta' ? 'selected' : ''); ?>>Quetta</option>
                                </select>
                            </li>
                            <li>
                                <h4>Province</h4>
                                <select class="form-control" name="province">
                                    <option value=""> --- Please Select --- </option>
                                    <option value="Punjab" <?php echo e($filters['province']=='Punjab' ? 'selected' : ''); ?>>Punjab</option>
                                    <option value="Sindh" <?php echo e($filters['province']=='Sindh' ? 'selected' : ''); ?>>Sindh</option>
                                    <option value="KPK" <?php echo e($filters['province']=='KPK' ? 'selected' : ''); ?>>KPK</option>
                                    <option value="Balochistan" <?php echo e($filters['province']=='Balochistan' ? 'selected' : ''); ?>>Balochistan</option>
                                    <option value="Azad Kashmir" <?php echo e($filters['province']=='Azad Kashmir' ? 'selected' : ''); ?>>Azad Kashmir</option>
                                    <option value="Federally Administered Tribal Areas" <?php echo e($filters['province']=='Federally Administered Tribal Areas' ? 'selected' : ''); ?>>Federally Administered Tribal Areas</option>
                                </select>
                            </li>
                            <li>
                                <h4>Color</h4>
                                <select class="form-control" name="color">
                                    <option value=""> --- Please Select --- </option>
                                    <option value="Red" <?php echo e($filters['color']=='Red' ? 'selected' : ''); ?>>Red</option>
                                    <option value="Black" <?php echo e($filters['color']=='Black' ? 'selected' : ''); ?>>Black</option>
                                    <option value="White" <?php echo e($filters['color']=='White' ? 'selected' : ''); ?>>White</option>
                                    <option value="Green" <?php echo e($filters['color']=='Green' ? 'selected' : ''); ?>>Green</option>
                                    <option value="Blue" <?php echo e($filters['color']=='Blue' ? 'selected' : ''); ?>>Blue</option>
                                    <option value="Orange" <?php echo e($filters['color']=='Orange' ? 'selected' : ''); ?>>Orange</option>
                                    <option value="Yellow" <?php echo e($filters['color']=='Yellow' ? 'selected' : ''); ?>>Yellow</option>
                                    <option value="Multi" <?php echo e($filters['color']=='Multi' ? 'selected' : ''); ?>>Multi</option>
                                </select>
                            </li>
                            <li>
                                <h4>Category</h4>
                                <select class="form-control" name="category">
                                    <option value=""> --- Please Select --- </option>
                                    <option value="Body Parts" <?php echo e($filters['category']=='Body Parts' ? 'selected' : ''); ?>>Body Parts</option>
                                    <option value="Wheels, Tyres and Rims" <?php echo e($filters['category']=='Wheels, Tyres and Rims' ? 'selected' : ''); ?>>Wheels, Tyres and Rims</option>
                                    <option value="Engine and Engine Parts" <?php echo e($filters['category']=='Engine and Engine Parts' ? 'selected' : ''); ?>>Engine and Engine Parts</option>
                                    <option value="Wrecking" <?php echo e($filters['category']=='Wrecking' ? 'selected' : ''); ?>>Wrecking</option>
                                    <option value="Brakes and Suspensions" <?php echo e($filters['category']=='Brakes and Suspensions' ? 'selected' : ''); ?>>Brakes and Suspensions</option>
                                    <option value="Oil, Liquids" <?php echo e($filters['category']=='Oil, Liquids' ? 'selected' : ''); ?>>Oil, Liquids</option>
                                    <option value="Other Parts" <?php echo e($filters['category']=='Other Parts' ? 'selected' : ''); ?>>Other Parts</option>
                                </select>
                            </li>
                            <li>
                                <h4>Price Type</h4>
                                <select class="form-control" name="price_type">
                                    <option value=""> --- Please Select --- </option>
                                    <option value="amount" <?php echo e($filters['price_type']=='amount' ? 'selected' : ''); ?>>Amount</option>
                                    <option value="negotiable" <?php echo e($filters['price_type']=='negotiable' ? 'selected' : ''); ?>>Negotiable</option>
                                    <option value="free" <?php echo e($filters['price_type']=='free' ? 'selected' : ''); ?>>Free</option>
                                    <option value="swap/trade" <?php echo e($filters['price_type']=='swap/trade' ? 'selected' : ''); ?>>Swap/Trade</option>
                                </select>
                            </li>
                            <li>
                                <h4>Condition</h4>
                                <select class="form-control" name="condition">
                                    <option value=""> --- Please Select --- </option>
                                    <option value="new" <?php echo e($filters['condition']=='new' ? 'selected' : ''); ?>>New</option>
                                    <option value="old" <?php echo e($filters['condition']=='old' ? 'selected' : ''); ?>>Old</option>
                                </select>
                            </li>
                            <li>
                                <h4>Offer Type</h4>
                                <select class="form-control" name="offer">
                                    <option value=""> --- Please Select --- </option>
                                    <option value="offer" <?php echo e($filters['offer']=='offer' ? 'selected' : ''); ?>>Offer</option>
                                    <option value="wanted" <?php echo e($filters['offer']=='wanted' ? 'selected' : ''); ?>>Wanted</option>
                                </select>
                            </li>

                            <button class="btn btn-default" type="submit">Submit</button>
                        </ul>
                    </form>
                </div>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <div class="cs-services bag">
                                <figure> <img class="img-responsive" src="<?php echo e(url($item->photos()->first()->getPicture())); ?>">
                                    <div class=" heart-o">
                                        <a href="#"><i class="fa fa-heart-o"></i></a>
                                        <div class=" heart-i">
                                            <a href="#"><i class="fa fa-heart"></i></a>
                                        </div>
                                    </div>
                                </figure>
                                <div class="heading"><h5><a href="#"><?php echo e($item->name); ?></a></h5>
                                    <p>PKR <?php echo e($item->price); ?></p>
                                    <small>Free Shipping</small>
                                </div>
                                <div class="h-over">
                                    <a class="btn btn-default" href="#">Buy Now</a>
                                    <a class="btn btn-default" href="#">View</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>

    <main class="wow fadeInDown page-section" style="visibility: visible; animation-name: fadeInDown;">
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>

    <script>
        function getVals(){
            // Get slider values
            var parent = this.parentNode;
            var slides = parent.getElementsByTagName("input");
            var slide1 = parseFloat( slides[0].value );
            var slide2 = parseFloat( slides[1].value );
            // Neither slider will clip the other, so make sure we determine which is larger
            if( slide1 > slide2 ){ var tmp = slide2; slide2 = slide1; slide1 = tmp; }

            var displayElement = parent.getElementsByClassName("rangeValues")[0];
            displayElement.innerHTML = "RS. " + slide1 + " - Rs." + slide2 + "";
        }

        window.onload = function(){
            // Initialize Sliders
            var sliderSections = document.getElementsByClassName("range-slider");
            for( var x = 0; x < sliderSections.length; x++ ){
                var sliders = sliderSections[x].getElementsByTagName("input");
                for( var y = 0; y < sliders.length; y++ ){
                    if( sliders[y].type ==="range" ){
                        sliders[y].oninput = getVals;
                        // Manually trigger event first time to display values
                        sliders[y].oninput();
                    }
                }
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Muhammad Abubakar\PhpstormProjects\Scooters\resources\views/user/accessories.blade.php ENDPATH**/ ?>