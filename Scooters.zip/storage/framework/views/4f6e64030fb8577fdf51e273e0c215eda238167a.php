<?php $__env->startSection('content'); ?>
    <main class="wow fadeInDown" style="visibility: visible; animation-name: fadeInDown;">
        <section class="page-section profile">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <h2><span><a href="#"> View Profile</a></span></h2>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <ul class="pull-right">
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Manage adds<span class="caret"></span> <span class="sr-only">(current)</span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">All Ads (0)</a></li>
                                        <li><a href="#">Current Ads (0)</a></li>
                                        <li><a href="#">Expired Ads (0)</a></li>
                                        <li><a href="#">Pending Ads (0)</a></li>
                                        <li><a href="#">All Ads (0)</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Messages</a></li>
                                <li><a href="#">Search alerts</a></li>
                                <li><a href="#">Profile settings</a></li>
                                <li><a class="active" href="#">View my full profile</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="card">
                                <h2><figure><img src="images/news2.jpg"> </figure> <span><?php echo e(Auth::user()->name); ?></span>
                                    <p> <small><?php echo e(Auth::user()->email); ?></small></p>
                                    <p> <small><?php echo e(Auth::user()->phone); ?></small></p>
                                </h2>

                            </div>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="card">
                                <h2>Live ads</h2>
                                <div class="add-area">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <?php $__currentLoopData = $bikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-12">
                                                <div class="cs-services box right">
                                                    <figure> <img class="img-responsive" src="<?php echo e(url($item->photos()->first()->getPicture())); ?>"></figure>
                                                    <div class="heading"><h5>
                                                            <a href="<?php echo e(url()->current().'/'.$item->id); ?>"><?php echo e($item->name); ?></a>
                                                        </h5>
                                                        <p><?php echo e($item->price); ?></p>
                                                        <p><?php echo e($item->description); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-12">
                                                    <div class="cs-services box right">
                                                        <figure> <img class="img-responsive" src="<?php echo e(url($item->photos()->first()->getPicture())); ?>"></figure>
                                                        <div class="heading"><h5>
                                                                <a href="<?php echo e(url()->current().'/'.$item->id); ?>"><?php echo e($item->name); ?></a>
                                                            </h5>
                                                            <p><?php echo e($item->price); ?></p>
                                                            <p><?php echo e($item->description); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <h2>Favorite Ads</h2>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Muhammad Abubakar\PhpstormProjects\Scooters\resources\views/user/viewprofile.blade.php ENDPATH**/ ?>