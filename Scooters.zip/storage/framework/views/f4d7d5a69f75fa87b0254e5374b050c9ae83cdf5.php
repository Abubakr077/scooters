<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body>
<a href="javascript:" id="return-to-top"><i class="fa fa-angle-up"></i></a>
<div class="wrapper">

        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('search'); ?>

    <?php echo $__env->yieldContent('content'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/wow.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
</div>
</body>
</html>
<?php /**PATH C:\Users\Muhammad Abubakar\PhpstormProjects\Scooters\resources\views/layouts/layout.blade.php ENDPATH**/ ?>